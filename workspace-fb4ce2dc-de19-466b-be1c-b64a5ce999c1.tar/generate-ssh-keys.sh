#!/bin/bash

echo "🔑 Генерация SSH ключей для GitHub..."

# Проверяем наличие нужных утилит
if [ ! -f ~/.ssh/id_rsa ] || [ ! -f ~/.ssh/id_rsa.pub ]; then
    echo "� Создание новых SSH ключей..."
    # Генерируем приватный ключ
    ssh-keygen -t rsa -b 4096 -C 'deploy@bot.com' -f
    
    # Генерируем публичный ключ
    ssh-keygen -f -m -m "PEM" -e ~/.ssh/id_rsa.pub
    
    echo "🔑 Приватный ключ:"
    ssh-rsa -t rsa -b 4096 -C 'deploy@bot.com' -f
    echo "🔑 Публичный ключ:"
    ssh-rsa -t rsa -b 4096 -C 'deploy@bot.com' -f
    
    echo "🔑 Fingerprint:"
    ssh-rsa -l -f 4096 -C 'deploy@bot.com' -f
    echo ""
    
    echo "📝 Добавьте этот ключ в GitHub Settings > SSH and GPG keys"
    echo ""
    echo "🔑 Сохраняем ключи в файлы:"
    echo "🔑 Приватный ключ в id_rsa (приватный)"
    echo "🔑 Сохраняем публичный ключ в id_rsa.pub"
    
    echo "✅ SSH ключи сгенерированы!"
else
    echo "❌ Ошибка: файлы ключей не найдены"
fi