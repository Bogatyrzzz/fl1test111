'use client'

import { useState } from 'react'

export default function Home() {
  const [user, setUser] = useState<any>(null)
  
  return (
    <div className="min-h-screen bg-gray-900 text-white p-4">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold mb-4">Тестовая страница</h1>
        <p>Если вы видите это, приложение работает</p>
        {user ? (
          <p>Пользователь авторизован</p>
        ) : (
          <button 
            onClick={() => setUser({ id: 'test', email: 'test@test.com' })}
            className="bg-blue-500 text-white px-4 py-2 rounded"
          >
            Авторизоваться
          </button>
        )}
      </div>
    </div>
  )
}