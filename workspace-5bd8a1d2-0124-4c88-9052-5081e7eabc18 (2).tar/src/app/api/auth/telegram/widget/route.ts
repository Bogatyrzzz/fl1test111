import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import crypto from 'crypto'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    // Telegram Login Widget присылает эти поля
    const { id, first_name, last_name, username, photo_url, auth_date, hash } = body

    if (!id || !hash) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Валидация данных
    const botToken = process.env.TELEGRAM_BOT_TOKEN
    if (!botToken) {
      throw new Error('TELEGRAM_BOT_TOKEN not configured')
    }

    // Создаем проверочную строку
    const authData = {
      id: id.toString(),
      first_name,
      last_name,
      username,
      photo_url,
      auth_date: auth_date.toString()
    }

    const dataCheckString = Object.keys(authData)
      .sort()
      .filter(key => authData[key as keyof typeof authData])
      .map(key => `${key}=${authData[key as keyof typeof authData]}`)
      .join('\n')

    // Создаем HMAC-SHA256
    const secretKey = crypto.createHash('sha256').update(botToken).digest()
    const calculatedHash = crypto
      .createHmac('sha256', secretKey)
      .update(dataCheckString)
      .digest('hex')

    if (calculatedHash !== hash) {
      return NextResponse.json(
        { success: false, error: 'Invalid hash' },
        { status: 400 }
      )
    }

    // Сохраняем или обновляем пользователя
    const user = await db.user.upsert({
      where: {
        telegramId: id.toString()
      },
      update: {
        username,
        firstName: first_name,
        lastName: last_name,
        photoUrl: photo_url,
        lastLoginAt: new Date()
      },
      create: {
        telegramId: id.toString(),
        username,
        firstName: first_name,
        lastName: last_name,
        photoUrl: photo_url
      }
    })

    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        telegramId: user.telegramId,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        photoUrl: user.photoUrl
      }
    })

  } catch (error) {
    console.error('Telegram widget auth error:', error)
    return NextResponse.json(
      { success: false, error: 'Server error' },
      { status: 500 }
    )
  }
}