import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import crypto from 'crypto'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { hash, ...authData } = body

    if (!hash) {
      return NextResponse.json(
        { success: false, error: 'Missing hash' },
        { status: 400 }
      )
    }

    // Валидация данных Telegram
    const botToken = process.env.TELEGRAM_BOT_TOKEN
    if (!botToken) {
      throw new Error('TELEGRAM_BOT_TOKEN not configured')
    }

    // Создаем проверочную строку
    const dataCheckString = Object.keys(authData)
      .filter(key => key !== 'state')
      .sort()
      .map(key => `${key}=${authData[key]}`)
      .join('\n')

    // Создаем HMAC-SHA256
    const secretKey = crypto.createHash('sha256').update(botToken).digest()
    const calculatedHash = crypto
      .createHmac('sha256', secretKey)
      .update(dataCheckString)
      .digest('hex')

    if (calculatedHash !== hash) {
      return NextResponse.json(
        { success: false, error: 'Invalid hash' },
        { status: 400 }
      )
    }

    // Извлекаем данные пользователя
    let userJson
    if (authData.user) {
      userJson = typeof authData.user === 'string' ? JSON.parse(authData.user) : authData.user
    } else if (authData.id) {
      // Прямые данные от OAuth
      userJson = {
        id: authData.id,
        first_name: authData.first_name,
        last_name: authData.last_name,
        username: authData.username,
        photo_url: authData.photo_url
      }
    }

    if (!userJson) {
      return NextResponse.json(
        { success: false, error: 'No user data' },
        { status: 400 }
      )
    }

    // Сохраняем или обновляем пользователя
    const user = await db.user.upsert({
      where: {
        telegramId: userJson.id.toString()
      },
      update: {
        username: userJson.username,
        firstName: userJson.first_name,
        lastName: userJson.last_name,
        photoUrl: userJson.photo_url,
        lastLoginAt: new Date()
      },
      create: {
        telegramId: userJson.id.toString(),
        username: userJson.username,
        firstName: userJson.first_name,
        lastName: userJson.last_name,
        photoUrl: userJson.photo_url
      }
    })

    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        telegramId: user.telegramId,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        photoUrl: user.photoUrl
      }
    })

  } catch (error) {
    console.error('Telegram validation error:', error)
    return NextResponse.json(
      { success: false, error: 'Server error' },
      { status: 500 }
    )
  }
}