import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const { telegramId, username, firstName, lastName, photoUrl, authDate, hash } = await request.json()

    // Special handling for mock users
    if (telegramId && telegramId.toString().startsWith('123456789-')) {
      // Find or create mock user
      let user = await db.user.findUnique({
        where: { telegramId }
      })

      if (!user) {
        user = await db.user.create({
          data: {
            telegramId,
            username: username || 'test_user',
            firstName: firstName || 'Тестовый',
            lastName: lastName || 'Пользователь',
            photoUrl: photoUrl || '',
            createdAt: new Date(),
            updatedAt: new Date()
          }
        })
      } else {
        // Update existing mock user
        user = await db.user.update({
          where: { telegramId },
          data: {
            username: username || user.username,
            firstName: firstName || user.firstName,
            lastName: lastName || user.lastName,
            photoUrl: photoUrl || user.photoUrl,
            updatedAt: new Date()
          }
        })
      }

      return NextResponse.json({
        success: true,
        user: {
          id: user.id,
          telegramId: user.telegramId,
          username: user.username,
          firstName: user.firstName,
          lastName: user.lastName,
          photoUrl: user.photoUrl
        }
      })
    }

    if (!telegramId || !firstName) {
      return NextResponse.json(
        { error: 'Missing required fields: telegramId and firstName are required' },
        { status: 400 }
      )
    }

    // Проверяем валидность данных от Telegram
    if (!authDate || !hash) {
      return NextResponse.json(
        { error: 'Invalid Telegram auth data: missing authDate or hash' },
        { status: 400 }
      )
    }

    // Find or create user
    let user = await db.user.findUnique({
      where: { telegramId }
    })

    if (!user) {
      user = await db.user.create({
        data: {
          telegramId,
          username,
          firstName,
          lastName,
          photoUrl,
          // Дополнительные поля для безопасности
          createdAt: new Date(authDate),
          updatedAt: new Date()
        }
      })
    } else {
      // Update existing user data
      user = await db.user.update({
        where: { telegramId },
        data: {
          username: username || user.username,
          firstName: firstName || user.firstName,
          lastName: lastName || user.lastName,
          photoUrl: photoUrl || user.photoUrl,
          updatedAt: new Date()
        }
      })
    }

    // Логируем успешную авторизацию
    console.log(`User ${user.firstName} (@${user.username}) authenticated at ${new Date().toISOString()}`)

    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        telegramId: user.telegramId,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        photoUrl: user.photoUrl
      }
    })

  } catch (error) {
    console.error('Telegram auth error:', error)
    return NextResponse.json(
      { error: 'Internal server error during authentication' },
      { status: 500 }
    )
  }
}