import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import crypto from 'crypto'

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const hash = searchParams.get('hash')
    
    if (!hash) {
      return NextResponse.redirect(
        new URL('/?error=missing_hash', request.url)
      )
    }

    // Получаем все параметры кроме hash
    const authData: any = {}
    searchParams.forEach((value, key) => {
      if (key !== 'hash') {
        authData[key] = value
      }
    })

    // Проверяем state для CSRF защиты
    const storedState = sessionStorage.getItem('telegram_oauth_state')
    if (authData.state !== storedState) {
      return NextResponse.redirect(
        new URL('/?error=invalid_state', request.url)
      )
    }

    // Валидация данных Telegram (аналогично WebApp)
    const botToken = process.env.TELEGRAM_BOT_TOKEN
    if (!botToken) {
      throw new Error('TELEGRAM_BOT_TOKEN not configured')
    }

    // Создаем проверочную строку
    const dataCheckString = Object.keys(authData)
      .filter(key => key !== 'state')
      .sort()
      .map(key => `${key}=${authData[key]}`)
      .join('\n')

    // Создаем HMAC-SHA256
    const secretKey = crypto.createHash('sha256').update(botToken).digest()
    const calculatedHash = crypto
      .createHmac('sha256', secretKey)
      .update(dataCheckString)
      .digest('hex')

    if (calculatedHash !== hash) {
      return NextResponse.redirect(
        new URL('/?error=invalid_hash', request.url)
      )
    }

    // Извлекаем данные пользователя
    const userJson = authData.user ? JSON.parse(authData.user) : null
    if (!userJson) {
      return NextResponse.redirect(
        new URL('/?error=no_user_data', request.url)
      )
    }

    // Сохраняем или обновляем пользователя в базе данных
    const user = await db.user.upsert({
      where: {
        telegramId: userJson.id.toString()
      },
      update: {
        username: userJson.username,
        firstName: userJson.first_name,
        lastName: userJson.last_name,
        photoUrl: userJson.photo_url,
        lastLoginAt: new Date()
      },
      create: {
        telegramId: userJson.id.toString(),
        username: userJson.username,
        firstName: userJson.first_name,
        lastName: userJson.last_name,
        photoUrl: userJson.photo_url
      }
    })

    // Перенаправляем на главную страницу с параметрами успеха
    const redirectUrl = new URL('/', request.url)
    redirectUrl.searchParams.set('auth', 'success')
    redirectUrl.searchParams.set('user', JSON.stringify({
      id: user.id,
      telegramId: user.telegramId,
      username: user.username,
      firstName: user.firstName,
      lastName: user.lastName,
      photoUrl: user.photoUrl
    }))

    return NextResponse.redirect(redirectUrl)

  } catch (error) {
    console.error('Telegram OAuth callback error:', error)
    return NextResponse.redirect(
      new URL('/?error=server_error', request.url)
    )
  }
}