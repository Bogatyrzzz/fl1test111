import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import crypto from 'crypto'

export async function POST(request: NextRequest) {
  try {
    const { email, password, fullName, isLogin } = await request.json()

    if (!email || !password) {
      return NextResponse.json(
        { error: 'Email и пароль обязательны' },
        { status: 400 }
      )
    }

    // Валидация домена - разрешаем поддомены
    const emailRegex = /^[a-zA-Z0-9._%+-]+@fl1capital\.com$/
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Почта должна быть на домене @fl1capital.com' },
        { status: 400 }
      )
    }

    if (!isLogin && !fullName) {
      return NextResponse.json(
        { error: 'Имя обязательно для регистрации' },
        { status: 400 }
      )
    }

    // Убираем обязательность fullName для входа
    // if (!isLogin && !fullName) {

    if (isLogin) {
      // Вход
      let user = await db.user.findUnique({
        where: { email }
      })

      if (!user) {
        return NextResponse.json(
          { error: 'Пользователь не найден' },
          { status: 404 }
        )
      }

      // Проверяем пароль (в реальном приложении нужно хеширование)
      const hashedPassword = crypto.createHash('sha256').update(password).digest('hex')
      if (user.password !== hashedPassword) {
        return NextResponse.json(
          { error: 'Неверный пароль' },
          { status: 401 }
        )
      }

      return NextResponse.json({
        success: true,
        user: {
          id: user.id,
          email: user.email,
          fullName: user.fullName,
          createdAt: user.createdAt
        }
      })

    } else {
      // Регистрация
      const existingUser = await db.user.findUnique({
        where: { email }
      })

      if (existingUser) {
        return NextResponse.json(
          { error: 'Пользователь с такой почтой уже существует' },
          { status: 409 }
        )
      }

      // Создаем нового пользователя
      const hashedPassword = crypto.createHash('sha256').update(password).digest('hex')
      const user = await db.user.create({
        data: {
          email,
          password: hashedPassword,
          fullName,
          createdAt: new Date(),
          updatedAt: new Date()
        }
      })

      return NextResponse.json({
        success: true,
        user: {
          id: user.id,
          email: user.email,
          fullName: user.fullName,
          createdAt: user.createdAt
        }
      })
    }

  } catch (error) {
    console.error('Email auth error:', error)
    return NextResponse.json(
      { error: 'Внутренняя ошибка сервера' },
      { status: 500 }
    )
  }
}