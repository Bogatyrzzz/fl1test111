'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { History, Trash2, Calendar, DollarSign, TrendingUp, AlertCircle, Edit2, Check, X } from 'lucide-react'

interface CalculationHistoryProps {
  userId: string
  onClose: () => void
}

interface HistoryItem {
  id: string
  title: string
  inputData: any
  resultData: any
  status: string
  errorMessage?: string
  createdAt: string
}

export function CalculationHistory({ userId, onClose }: CalculationHistoryProps) {
  const [history, setHistory] = useState<HistoryItem[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string>('')
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editingTitle, setEditingTitle] = useState<string>('')

  useEffect(() => {
    console.log('CalculationHistory useEffect triggered, userId:', userId)
    if (!userId) {
      console.log('No userId provided, skipping history fetch')
      return
    }
    fetchHistory()
  }, [userId])

  const fetchHistory = async () => {
    console.log('fetchHistory called')
    setIsLoading(true)
    setError('')
    
    try {
      const response = await fetch(`/api/calculations/history?userId=${userId}&type=ipo`)
      console.log('Fetch URL:', `/api/calculations/history?userId=${userId}&type=ipo`)
      const data = await response.json()
      console.log('Fetch response:', data)
      
      if (data.success) {
        console.log('Setting history:', data.calculations)
        setHistory(data.calculations)
      } else {
        console.log('Fetch error:', data.error)
        setError(data.error || 'Ошибка при загрузке истории')
      }
    } catch (err) {
      console.error('Error fetching history:', err)
      setError('Ошибка соединения с сервером')
    } finally {
      setIsLoading(false)
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleString('ru-RU', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ru-RU', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount)
  }

  const clearHistory = async () => {
    if (!confirm('Вы уверены, что хотите удалить всю историю расчетов?')) {
      return
    }

    try {
      const response = await fetch('/api/calculations/clear', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ userId })
      })

      const data = await response.json()
      
      if (data.success) {
        setHistory([])
      } else {
        setError(data.error || 'Ошибка при очистке истории')
      }
    } catch (err) {
      console.error('Error clearing history:', err)
      setError('Ошибка соединения с сервером')
    }
  }

  const updateTitle = async (id: string, newTitle: string) => {
    if (!newTitle.trim()) {
      return
    }
    
    try {
      const response = await fetch('/api/calculations/update-title', {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ id, title: newTitle.trim() })
      })

      const data = await response.json()
      
      if (data.success) {
        setHistory(prev => prev.map(item => 
          item.id === id ? { ...item, title: newTitle.trim() } : item
        ))
        setEditingId(null)
        setEditingTitle('')
      } else {
        setError(data.error || 'Ошибка при обновлении названия')
      }
    } catch (err) {
      console.error('Error updating title:', err)
      setError('Ошибка соединения с сервером')
    }
  }

  const startEditing = (id: string, currentTitle: string) => {
    setEditingId(id)
    setEditingTitle(currentTitle)
  }

  const cancelEditing = () => {
    setEditingId(null)
    setEditingTitle('')
  }

  const saveEditing = (id: string) => {
    updateTitle(id, editingTitle)
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-amber-950 via-amber-900 to-amber-950 text-white p-4 flex items-center justify-center">
        <div className="w-12 h-12 border-3 border-yellow-400 border-t-transparent rounded-full animate-spin mx-auto" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-950 via-amber-900 to-amber-950 text-white p-4">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold text-white flex items-center gap-3">
            <History className="w-8 h-8 text-yellow-400" />
            История расчетов IPO
          </h2>
          <Button
            onClick={onClose}
            variant="outline"
            className="border-amber-400 text-white hover:bg-amber-800 font-semibold bg-amber-600/10"
          >
            Закрыть
          </Button>
        </div>

        {error && (
          <Card className="mb-6 border-red-500/30 bg-red-500/10">
            <CardContent className="pt-6">
              <div className="flex items-center gap-3 text-red-400">
                <AlertCircle className="w-5 h-5" />
                <span>{error}</span>
              </div>
            </CardContent>
          </Card>
        )}

        {history.length === 0 && !isLoading && !error && (
          <Card className="text-center py-12">
            <CardContent>
              <History className="w-16 h-16 text-amber-400/50 mx-auto mb-4" />
              <CardTitle className="text-xl font-semibold text-white mb-2">
                История пуста
              </CardTitle>
              <CardDescription className="text-amber-100">
                Вы еще не выполнили ни одного расчета. Начните с новой страницы расчетов.
              </CardDescription>
            </CardContent>
          </Card>
        )}

        {history.length > 0 && (
          <div className="grid gap-4">
            {history.map((item) => (
              <Card key={item.id} className="bg-white/10 backdrop-blur-md border border-yellow-400/30">
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      {editingId === item.id ? (
                        <div className="flex items-center gap-2 mb-2">
                          <input
                            type="text"
                            value={editingTitle}
                            onChange={(e) => setEditingTitle(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                saveEditing(item.id)
                              } else if (e.key === 'Escape') {
                                cancelEditing()
                              }
                            }}
                            className="flex-1 bg-white/20 border border-white/30 rounded px-3 py-2 text-white placeholder-white/50 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                            placeholder="Введите название"
                            autoFocus
                          />
                          <Button
                            type="button"
                            onClick={() => saveEditing(item.id)}
                            size="sm"
                            className="bg-green-500 hover:bg-green-600 text-white p-2 h-8"
                          >
                            <Check className="w-4 h-4" />
                          </Button>
                          <Button
                            type="button"
                            onClick={cancelEditing}
                            size="sm"
                            className="bg-red-500 hover:bg-red-600 text-white p-2 h-8"
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-2 mb-1">
                          <CardTitle className="text-lg font-semibold text-white">
                            {item.title}
                          </CardTitle>
                          <Button
                            type="button"
                            onClick={() => startEditing(item.id, item.title)}
                            size="sm"
                            variant="ghost"
                            className="text-white/70 hover:text-white hover:bg-white/10 p-2 h-8"
                          >
                            <Edit2 className="w-4 h-4" />
                          </Button>
                        </div>
                      )}
                      <div className="flex items-center gap-4 text-sm text-amber-100">
                        <Calendar className="w-4 h-4" />
                        <span>{formatDate(item.createdAt)}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge 
                        variant={item.status === 'completed' ? 'default' : 'destructive'}
                        className={item.status === 'completed' ? 'bg-green-500' : 'bg-red-500'}
                      >
                        {item.status === 'completed' ? 'Выполнено' : 'Ошибка'}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  {/* Входные данные */}
                  <div className="bg-black/20 rounded-lg p-4">
                    <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-yellow-400" />
                      Входные данные
                    </h4>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-white/70">Текущие юниты:</span>
                        <span className="text-white font-medium ml-2">
                          {item.inputData.currentUnits?.toFixed(2) || '0'}
                        </span>
                      </div>
                      <div>
                        <span className="text-white/70">Цена покупки:</span>
                        <span className="text-white font-medium ml-2">
                          {formatCurrency(item.inputData.purchasePrice || 0)}
                        </span>
                      </div>
                      <div>
                        <span className="text-white/70">Текущая цена:</span>
                        <span className="text-white font-medium ml-2">
                          {formatCurrency(item.inputData.currentPrice || 0)}
                        </span>
                      </div>
                      <div>
                        <span className="text-white/70">Комиссия:</span>
                        <span className="text-white font-medium ml-2">
                          {item.inputData.commissionRate || 0}%
                        </span>
                      </div>
                      <div>
                        <span className="text-white/70">Целевая сумма:</span>
                        <span className="text-white font-medium ml-2">
                          {formatCurrency(item.inputData.targetAmount || 0)}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Результаты расчета */}
                  {item.status === 'completed' && item.resultData ? (
                    <div className="bg-green-500/20 rounded-lg p-4">
                      <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-yellow-300" />
                        Результаты расчета
                      </h4>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-white/90">Продать юнитов:</span>
                          <span className="text-white font-medium ml-2">
                            {item.resultData.unitsToSell?.toFixed(2) || '0'}
                          </span>
                        </div>
                        <div>
                          <span className="text-white/90">Общая сумма:</span>
                          <span className="text-white font-medium ml-2">
                            {formatCurrency(item.resultData.totalAmount || 0)}
                          </span>
                        </div>
                        <div>
                          <span className="text-white/90">Чистая прибыль:</span>
                          <span className="text-white font-medium ml-2">
                            {formatCurrency(item.resultData.netProfit || 0)}
                          </span>
                        </div>
                        <div>
                          <span className="text-white/90">Комиссия:</span>
                          <span className="text-white font-medium ml-2">
                            {formatCurrency(item.resultData.commissionAmount || 0)}
                          </span>
                        </div>
                      </div>
                    </div>
                  ) : item.errorMessage ? (
                    <div className="bg-red-500/20 rounded-lg p-4">
                      <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 text-yellow-300" />
                        Ошибка расчета
                      </h4>
                      <p className="text-red-100 text-sm">
                        {item.errorMessage}
                      </p>
                    </div>
                  ) : null}
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {history.length > 0 && (
          <div className="mt-8 text-center">
            <Button
              onClick={clearHistory}
              variant="outline"
              className="border-red-400 text-white hover:bg-red-800 font-semibold bg-red-600/10"
            >
              <div className="flex items-center gap-2">
                <Trash2 className="w-4 h-4" />
                Очистить историю
              </div>
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}