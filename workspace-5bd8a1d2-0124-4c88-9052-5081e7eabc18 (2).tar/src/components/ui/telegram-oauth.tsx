'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { User, Shield, CheckCircle, AlertCircle } from 'lucide-react'

interface SimpleAuthProps {
  onAuth: (userData: any) => void
  onError: (error: string) => void
  isLoading?: boolean
}

export function SimpleAuth({ onAuth, onError, isLoading = false }: SimpleAuthProps) {
  const [authStatus, setAuthStatus] = useState<'idle' | 'checking' | 'success' | 'error'>('idle')
  const [statusMessage, setStatusMessage] = useState<string>('')

  const handleMockAuth = () => {
    // Временные мокап данные для тестирования
    const timestamp = Date.now()
    const mockUser = {
      id: 'mock-user-id-' + timestamp,
      telegramId: '123456789-' + timestamp, // Уникальный telegramId
      username: 'test_user',
      firstName: 'Тестовый',
      lastName: 'Пользователь',
      photoUrl: ''
    }
    
    setAuthStatus('checking')
    setStatusMessage('Выполняем вход...')
    
    // Имитируем задержку для реалистичности
    setTimeout(() => {
      setAuthStatus('success')
      setStatusMessage('Вход выполнен успешно!')
      onAuth(mockUser)
    }, 1000)
  }

  return (
    <Card className="bg-white/10 backdrop-blur-md border border-yellow-400/30 shadow-2xl max-w-md mx-auto">
      <CardHeader className="text-center pb-6">
        <div className="flex justify-center mb-4">
          <div className="p-4 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl shadow-lg">
            <User className="w-12 h-12 text-white" />
          </div>
        </div>
        <CardTitle className="text-2xl font-bold text-white mb-2">
          Вход в систему
        </CardTitle>
        <CardDescription className="text-amber-100 text-base">
          Быстрый доступ к финансовым расчетам
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {authStatus === 'idle' && (
          <>
            <div className="space-y-4">
              <div className="flex items-center gap-3 text-white/90">
                <Shield className="w-5 h-5 text-green-400 flex-shrink-0" />
                <span className="text-sm">Безопасный вход</span>
              </div>
              <div className="flex items-center gap-3 text-white/90">
                <User className="w-5 h-5 text-blue-400 flex-shrink-0" />
                <span className="text-sm">Полный доступ к расчетам</span>
              </div>
              <div className="flex items-center gap-3 text-white/90">
                <CheckCircle className="w-5 h-5 text-yellow-400 flex-shrink-0" />
                <span className="text-sm">Мгновенный старт</span>
              </div>
            </div>

            <div className="space-y-4">
              <div className="text-center">
                <p className="text-white/80 text-sm mb-4">Нажмите кнопку ниже для быстрого входа и тестирования всех функций</p>
              </div>
              
              <div className="text-center">
                <Button
                  onClick={handleMockAuth}
                  disabled={isLoading}
                  className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white font-semibold h-14 rounded-xl shadow-lg transform transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]"
                >
                  <div className="flex items-center gap-3">
                    <User className="w-5 h-5" />
                    <span>Войти и начать работу</span>
                  </div>
                </Button>
                
                <p className="text-white/60 text-xs mt-3">
                  Без регистрации - полный доступ ко всем расчетам
                </p>
              </div>
            </div>
          </>
        )}

        {authStatus === 'checking' && (
          <div className="text-center py-8">
            <div className="w-12 h-12 border-3 border-yellow-400 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
            <p className="text-white font-medium">{statusMessage}</p>
            <p className="text-white/70 text-sm mt-2">Это может занять несколько секунд...</p>
          </div>
        )}

        {authStatus === 'success' && (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="w-8 h-8 text-white" />
            </div>
            <p className="text-green-400 font-semibold text-lg mb-2">Успешный вход!</p>
            <p className="text-white/80">{statusMessage}</p>
            <p className="text-white/60 text-sm mt-2">Перенаправляем в приложение...</p>
          </div>
        )}

        {authStatus === 'error' && (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertCircle className="w-8 h-8 text-white" />
            </div>
            <p className="text-red-400 font-semibold text-lg mb-2">Ошибка</p>
            <p className="text-white/80 mb-4">{statusMessage}</p>
            <Button
              onClick={() => setAuthStatus('idle')}
              variant="outline"
              className="border-amber-400 text-white hover:bg-amber-800 font-semibold"
            >
              Попробовать снова
            </Button>
          </div>
        )}

        <div id="telegram-widget-container" className="hidden" />
        
        <div className="text-center">
          <Badge variant="secondary" className="bg-white/10 text-white/80 border-white/20">
            <Shield className="w-3 h-3 mr-1" />
            Защищенное соединение
          </Badge>
        </div>
      </CardContent>
    </Card>
  )
}