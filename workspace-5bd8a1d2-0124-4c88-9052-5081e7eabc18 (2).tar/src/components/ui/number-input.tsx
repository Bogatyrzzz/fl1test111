'use client'

import { useState } from 'react'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { ChevronUp, ChevronDown } from 'lucide-react'

interface NumberInputProps {
  id: string
  label: string
  value: number
  onChange: (value: number) => void
  placeholder?: string
  step?: number
  min?: number
  max?: number
  className?: string
}

export function NumberInput({ 
  id, 
  label, 
  value, 
  onChange, 
  placeholder, 
  step = 0.01,
  min,
  max,
  className = ""
}: NumberInputProps) {
  const [isHovered, setIsHovered] = useState(false)

  const handleIncrement = () => {
    const newValue = parseFloat((value + step).toFixed(10)) // Avoid floating point issues
    if (max !== undefined && newValue > max) return
    onChange(newValue)
  }

  const handleDecrement = () => {
    const newValue = parseFloat((value - step).toFixed(10)) // Avoid floating point issues
    if (min !== undefined && newValue < min) return
    onChange(newValue)
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = parseFloat(e.target.value) || 0
    if (min !== undefined && newValue < min) return
    if (max !== undefined && newValue > max) return
    onChange(newValue)
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowUp') {
      e.preventDefault()
      handleIncrement()
    } else if (e.key === 'ArrowDown') {
      e.preventDefault()
      handleDecrement()
    }
  }

  return (
    <div className="group">
      <Label htmlFor={id} className="text-white font-medium text-sm mb-2 block">
        {label}
      </Label>
      <div 
        className="number-input-wrapper"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        <Input 
          id={id} 
          type="number"
          step={step}
          min={min}
          max={max}
          placeholder={placeholder}
          className={`custom-number-input bg-white/10 border-yellow-400/20 text-white placeholder-white/50 focus:border-yellow-400 focus:ring-yellow-400/20 h-12 text-lg rounded-xl transition-all duration-200 pr-12 ${className}`}
          value={value || ''}
          onChange={handleChange}
          onKeyDown={handleKeyDown}
        />
        <div className="arrow-controls" style={{ opacity: isHovered ? 1 : 0 }}>
          <button 
            type="button"
            className="arrow-btn"
            onClick={handleIncrement}
            aria-label="Increase value"
            tabIndex={-1}
          >
            <ChevronUp />
          </button>
          <button 
            type="button"
            className="arrow-btn"
            onClick={handleDecrement}
            aria-label="Decrease value"
            tabIndex={-1}
          >
            <ChevronDown />
          </button>
        </div>
      </div>
    </div>
  )
}