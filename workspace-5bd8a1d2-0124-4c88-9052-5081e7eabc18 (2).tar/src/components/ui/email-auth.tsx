'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { AlertCircle, Loader2, Mail, Lock, User, CheckCircle } from 'lucide-react'

interface EmailAuthProps {
  onAuth: (userData: { id: string; email: string; fullName: string }) => void
  onError: (message: string) => void
}

function EmailAuth({ onAuth, onError }: EmailAuthProps) {
  const [isLogin, setIsLogin] = useState(true)
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [fullName, setFullName] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  const validateEmail = (email: string) => {
    // Проверяем, что домен строго @fl1capital.com
    const emailRegex = /^[a-zA-Z0-9._%+-]+@fl1capital\.com$/
    return emailRegex.test(email)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setSuccess('')
    
    // Валидация
    if (!email || !password) {
      setError('Заполните все поля')
      onError('Заполните все поля')
      return
    }

    if (!validateEmail(email)) {
      setError('Почта должна быть на домене @fl1capital.com')
      onError('Почта должна быть на домене @fl1capital.com')
      return
    }

    if (!isLogin && !fullName) {
      setError('Введите ваше имя для регистрации')
      onError('Введите ваше имя для регистрации')
      return
    }

    setIsLoading(true)

    try {
      const response = await fetch('/api/auth/email', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email,
          password,
          fullName,
          isLogin,
        }),
      })

      const data = await response.json()

      if (response.ok) {
        setSuccess(isLogin ? 'Вход выполнен успешно!' : 'Регистрация выполнена успешно!')
        
        // Сохраняем email в localStorage для истории
        localStorage.setItem('userEmail', email)
        
        onAuth({
          id: data.user.id,
          email: data.user.email,
          fullName: data.user.fullName,
        })
      } else {
        setError(data.error || 'Ошибка авторизации')
        onError(data.error || 'Ошибка авторизации')
      }
    } catch (error) {
      const errorMessage = 'Ошибка соединения с сервером'
      setError(errorMessage)
      onError(errorMessage)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-amber-50 to-orange-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-white/95 backdrop-blur-sm shadow-2xl">
        <div className="p-8">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-amber-500 to-orange-600 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Mail className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">
              {isLogin ? 'Вход в систему' : 'Создание аккаунта'}
            </h1>
            <p className="text-gray-600">
              {isLogin 
                ? 'Войдите для доступа к расчетам' 
                : 'Создайте аккаунт для доступа к расчетам'
              }
            </p>
          </div>

          {/* Success Message */}
          {success && (
            <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center">
              <CheckCircle className="w-5 h-5 text-green-600 mr-3 flex-shrink-0" />
              <p className="text-green-800 text-sm font-medium">{success}</p>
            </div>
          )}

          {/* Error Message */}
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start">
              <AlertCircle className="w-5 h-5 text-red-600 mr-3 flex-shrink-0 mt-0.5" />
              <p className="text-red-800 text-sm font-medium">{error}</p>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Full Name Field (only for registration) */}
            {!isLogin && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <User className="w-4 h-4 inline mr-2" />
                  Полное имя
                </label>
                <Input
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Введите ваше имя"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                  required={!isLogin}
                />
              </div>
            )}

            {/* Email Field */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Mail className="w-4 h-4 inline mr-2" />
                Email адрес
              </label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@fl1capital.com"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                required
              />
              <p className="text-xs text-gray-500 mt-1">
                Только для домена @fl1capital.com
              </p>
            </div>

            {/* Password Field */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Lock className="w-4 h-4 inline mr-2" />
                Пароль
              </label>
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Введите пароль"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
                required
              />
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white font-semibold py-3 px-4 rounded-lg transition-all duration-200 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  {isLogin ? 'Вход...' : 'Создание аккаунта...'}
                </>
              ) : (
                isLogin ? 'Войти' : 'Создать аккаунт'
              )}
            </Button>
          </form>

          {/* Toggle Auth Mode */}
          <div className="mt-6 text-center">
            <button
              type="button"
              onClick={() => {
                setIsLogin(!isLogin)
                setError('')
                setSuccess('')
              }}
              className="text-amber-600 hover:text-amber-700 font-medium text-sm transition-colors"
            >
              {isLogin 
                ? 'Нет аккаунта? Создать' 
                : 'Уже есть аккаунт? Войти'
              }
            </button>
          </div>
        </div>
      </Card>
    </div>
  )
}

export default EmailAuth