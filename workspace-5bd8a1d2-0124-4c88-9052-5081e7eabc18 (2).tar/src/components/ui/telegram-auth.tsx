'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Loader2, Shield, CheckCircle, AlertCircle } from 'lucide-react'

interface TelegramAuthProps {
  onAuthSuccess: (userData: any) => void
  onAuthError: (error: string) => void
}

declare global {
  interface Window {
    Telegram: {
      Login: {
        auth: (callback: (data: any) => void, options?: any) => void
        off: (callback: (data: any) => void) => void
      }
    }
    WebApp: {
      ready: () => void
      expand: () => void
      close: () => void
    }
  }
}

export function TelegramAuth({ onAuthSuccess, onAuthError }: TelegramAuthProps) {
  const [isLoading, setIsLoading] = useState(false)
  const [isTelegramReady, setIsTelegramReady] = useState(false)
  const [authStatus, setAuthStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle')

  useEffect(() => {
    // Проверяем, доступен ли Telegram WebApp API
    const checkTelegramReady = () => {
      if (window.Telegram && window.Telegram.Login) {
        setIsTelegramReady(true)
        console.log('Telegram Login API is ready')
      } else {
        // Если Telegram API недоступен, используем альтернативный метод
        setTimeout(() => {
          setIsTelegramReady(false)
          setAuthStatus('error')
          onAuthError('Telegram WebApp API недоступен. Пожалуйста, откройте приложение через Telegram.')
        }, 2000)
      }
    }

    // Таймаут для проверки доступности Telegram
    const timeout = setTimeout(() => {
      if (!isTelegramReady) {
        checkTelegramReady()
      }
    }, 5000)

    // Проверяем готовность API
    if (document.readyState === 'complete') {
      checkTelegramReady()
    } else {
      document.addEventListener('DOMContentLoaded', checkTelegramReady)
    }

    // Также проверяем через window.TelegramWebviewProxy
    const checkWebviewProxy = () => {
      if (window.TelegramWebviewProxy) {
        setIsTelegramReady(true)
        console.log('Telegram WebviewProxy is ready')
      }
    }

    if (window.TelegramWebviewProxy) {
      checkWebviewProxy()
    }

    return () => {
      clearTimeout(timeout)
      document.removeEventListener('DOMContentLoaded', checkTelegramReady)
    }
  }, [])

  const handleTelegramAuth = () => {
    if (!window.Telegram || !window.Telegram.Login) {
      // Альтернативный метод - открываем Telegram бота
      const botUsername = process.env.NEXT_PUBLIC_TELEGRAM_BOT_USERNAME || 'your_bot_username'
      const authUrl = `https://t.me/${botUsername}?start=auth`
      window.open(authUrl, '_blank')
      
      setAuthStatus('error')
      onAuthError(`Пожалуйста, откройте приложение через Telegram бота @${botUsername}`)
      return
    }

    setIsLoading(true)
    setAuthStatus('loading')

    // Настраиваем Telegram Login Widget
    window.Telegram.Login.auth(
      (data: any) => {
        console.log('Telegram auth data:', data)
        
        if (data) {
          // Пользователь успешно авторизовался
          const userData = {
            id: data.id,
            telegramId: data.id.toString(),
            username: data.username,
            firstName: data.first_name,
            lastName: data.last_name,
            photoUrl: data.photo_url,
            authDate: data.auth_date,
            hash: data.hash
          }

          setAuthStatus('success')
          onAuthSuccess(userData)
        } else {
          // Пользователь отменил авторизацию
          setAuthStatus('error')
          onAuthError('Авторизация была отменена')
        }
        
        setIsLoading(false)
      },
      {
        // Параметры для авторизации
        bot_id: process.env.NEXT_PUBLIC_TELEGRAM_BOT_ID || '', // ID вашего Telegram бота
        request_access: 'write', // Запрашиваем права на запись
        embed: 1, // Встроенный режим
        // Дополнительные параметры
        return_to: window.location.href,
        // Язык интерфейса
        lang: 'ru'
      }
    )

    // Обработчик закрытия виджета
    window.Telegram.Login.off((data: any) => {
      if (!data) {
        setIsLoading(false)
        setAuthStatus('idle')
      }
    })

    // Таймаут для авторизации
    setTimeout(() => {
      if (isLoading) {
        setIsLoading(false)
        setAuthStatus('error')
        onAuthError('Время авторизации истекло. Попробуйте еще раз.')
      }
    }, 60000) // 60 секунд
  }

  const renderAuthContent = () => {
    switch (authStatus) {
      case 'loading':
        return (
          <div className="flex flex-col items-center gap-4">
            <Loader2 className="w-8 h-8 text-yellow-400 animate-spin" />
            <p className="text-amber-100 text-center">Ожидание авторизации в Telegram...</p>
            <p className="text-amber-200 text-sm text-center">Пожалуйста, подтвердите авторизацию в Telegram</p>
          </div>
        )
      
      case 'success':
        return (
          <div className="flex flex-col items-center gap-4">
            <CheckCircle className="w-8 h-8 text-green-400" />
            <p className="text-amber-100 text-center">Авторизация успешна!</p>
            <p className="text-amber-200 text-sm text-center">Перенаправление в приложение...</p>
          </div>
        )
      
      case 'error':
        return (
          <div className="flex flex-col items-center gap-4">
            <AlertCircle className="w-8 h-8 text-red-400" />
            <p className="text-amber-100 text-center">Ошибка авторизации</p>
            <p className="text-amber-200 text-sm text-center">
              {!isTelegramReady 
                ? 'Пожалуйста, откройте приложение через Telegram'
                : 'Попробуйте еще раз или обратитесь в поддержку'
              }
            </p>
          </div>
        )
      
      default:
        return (
          <div className="flex flex-col items-center gap-6">
            <div className="w-16 h-16 bg-gradient-to-br from-yellow-500 to-amber-600 rounded-2xl flex items-center justify-center shadow-lg">
              <svg className="w-10 h-10 text-white" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.14.18-.357.223-.548.223l.188-2.84 5.18-4.68c.223-.198-.054-.308-.346-.11l-6.4 4.02-2.76-.918c-.6-.187-.612-.6.125-.89l10.782-4.156c.5-.18.94.12.78.88z"/>
              </svg>
            </div>
            <div className="text-center">
              <h3 className="text-xl font-bold text-white mb-2">Авторизация через FL1</h3>
              <p className="text-amber-100 mb-6">Безопасный вход через ваш Telegram аккаунт</p>
            </div>
          </div>
        )
    }
  }

  return (
    <Card className="bg-white/10 backdrop-blur-md border border-yellow-400/30 shadow-2xl">
      <CardHeader className="text-center pb-6">
        <div className="flex items-center justify-center gap-3 mb-4">
          <Shield className="w-6 h-6 text-yellow-400" />
          <CardTitle className="text-2xl text-white">Безопасная авторизация</CardTitle>
        </div>
        <CardDescription className="text-amber-100 text-base">
          Используйте ваш Telegram аккаунт для входа
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {renderAuthContent()}
        
        {authStatus === 'idle' && (
          <Button 
            onClick={handleTelegramAuth}
            disabled={isLoading || !isTelegramReady}
            className="w-full bg-gradient-to-r from-yellow-500 to-amber-600 hover:from-yellow-600 hover:to-amber-700 text-white font-semibold h-14 rounded-xl shadow-lg transform transition-all duration-200 hover:scale-[1.02] active:scale-[0.98]"
          >
            {isLoading ? (
              <div className="flex items-center gap-3">
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>Авторизация...</span>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.446 1.394c-.14.18-.357.223-.548.223l.188-2.84 5.18-4.68c.223-.198-.054-.308-.346-.11l-6.4 4.02-2.76-.918c-.6-.187-.612-.6.125-.89l10.782-4.156c.5-.18.94.12.78.88z"/>
                </svg>
                <span>Войти через FL1</span>
              </div>
            )}
          </Button>
        )}

        {!isTelegramReady && authStatus === 'idle' && (
          <div className="text-center">
            <p className="text-amber-200 text-sm mb-3">
              Telegram WebApp API недоступен. Убедитесь, что вы открыли приложение через Telegram.
            </p>
            <Button 
              onClick={() => window.open('https://web.telegram.org', '_blank')}
              variant="outline"
              className="border-yellow-400 text-white hover:bg-amber-800"
            >
              Открыть Telegram
            </Button>
          </div>
        )}

        <div className="text-center">
          <p className="text-amber-200 text-xs">
            Ваши данные защищены и не будут переданы третьим лицам
          </p>
        </div>
      </CardContent>
    </Card>
  )
}