# Настройка Telegram OAuth

## Текущий статус
✅ **Работает**: Telegram Login Widget (рекомендуемый метод)
❌ **Отключен**: OAuth popup (требует настройки домена)

## Как включить OAuth popup

Если вы хотите включить OAuth popup метод, нужно:

### 1. Настроить домен в Telegram Bot
1. Перейдите в [@BotFather](https://t.me/BotFather)
2. Выберите вашего бота: `/mybots`
3. Выберите `fl1_mathcalc_bot`
4. Откройте `Bot Settings` → `Domain`
5. Добавьте ваш домен (например: `yourdomain.com`)

### 2. Включить OAuth в коде
В файле `/src/components/ui/telegram-oauth.tsx` раскомментируйте код в функции `handleTelegramOAuth`:

```javascript
const handleTelegramOAuth = () => {
    // Удалите эти строки:
    setAuthStatus('error')
    setStatusMessage('OAuth временно недоступен...')
    
    // И раскомментируйте весь код ниже:
    /* 
    // Параметры для OAuth авторизации Telegram
    const botId = process.env.NEXT_PUBLIC_TELEGRAM_BOT_ID || '8468366813'
    // ... весь остальной код
    */
}
```

### 3. Обновить UI
Замените блок `authStatus === 'idle'` чтобы показать обе кнопки.

## Рекомендация
**Telegram Login Widget** - более надежный метод:
- ✅ Не требует настройки домена
- ✅ Работает сразу
- ✅ Такой же безопасный
- ✅ Лучше поддерживается

## Безопасность
Оба метода используют:
- HMAC-SHA256 валидацию
- CSRF защиту
- HTTPS соединения
- Проверку подлинности Telegram